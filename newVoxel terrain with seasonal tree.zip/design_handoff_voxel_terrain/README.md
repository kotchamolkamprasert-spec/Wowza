# Handoff: Voxel Terrain — QR Canopy Island & Soil Assembly

Two 3D voxel scenes built as browser prototypes, plus the generator code behind
them. This package is self-contained: open either `.html` file from the folder
root in a browser and it runs.

## Overview

**Scene A — `Voxel Island.html`.** A floating voxel island on a 33 × 33 grid: a
grass surface with a pond, a dirt path, rocks, flowers and fallen petals, over a
four-horizon geological cutaway (topsoil, sandy subsoil, clay, tapered bedrock).
A blocky tree grows from the centre; its roots run down into the subsoil and show
in the cut faces. The canopy is not decorative — its 25 × 25 plan is a real,
scannable Version 2-M QR code encoding `the god father is Dr.krirk`. Four canopy
palettes (Cherry Blossom, Summer Green, Golden Ginkgo, Pixel Mix) swap at
runtime.

**Scene B — `Soil and Seed.html`.** The same horizons at a quarter of the
resolution (13 × 13 grid, 0.16 m voxels), with no tree: a bare soil block and a
single seed in a planting dip. It plays a one-shot assembly animation — horizons
drop in bottom-up, pebbles land, the seed falls into the dip, a sprout grows —
and can be replayed from a button.

Both scenes export as OBJ+MTL or GLB from the viewer toolbar.

## About the design files

The files in this bundle are **design references created in HTML** — prototypes
showing the intended geometry, palette, lighting and motion. They are not
production code to drop into an app.

The generator modules (`voxel-island.js`, `soil-seed.js`, `qr.js`) are the
exception worth reading closely: they are plain ES modules with no framework
dependency and no build step, and the *algorithms* in them (strata rules, QR
plotting, face-culled meshing, the animation timeline) are the actual design.
Port those rules into the target environment — react-three-fiber, a Unity/Godot
scene, a native renderer, or a server-side mesh generator — rather than
transcribing the HTML pages.

`three-d-stage.js` is a viewer shell (renderer, lights, orbit controls, export
toolbar) used to present the work. In a real codebase it should be replaced by
whatever scene host that codebase already has.

## Fidelity

**High-fidelity.** Colors, voxel dimensions, strata depths, canopy profile,
lighting response and animation timings are all final and exact — every value is
listed in this package. Rebuild to these numbers.

Two caveats:

- Both pages carry a small 2D overlay (title block, season buttons, replay
  button) styled with the **Classical** design system. That overlay is
  presentation chrome for the prototype, not part of the deliverable. If the
  target app has its own UI system, use it.
- The QR code must stay byte-exact. Re-deriving it with a different encoder,
  mask, or error-correction level produces a different matrix; see
  `docs/03-qr-canopy.md`.

## Scenes

### A. Voxel Island (`Voxel Island.html`)

- **Purpose:** an inspectable hero object — orbit it, switch seasons, export the
  mesh. The reveal is that the canopy reads as a QR code from directly overhead.
- **Composition:** a single floating island, framed from a fixed three-quarter
  near-isometric angle, on a warm beige ground (`#f2e8d7`) with a soft contact
  shadow beneath it.
- **Extents:** 33 × 33 voxels in plan (2.97 m), y from −17 to ~26 (≈ 3.9 m tall).
- **Contents:** surface features, four soil horizons, trunk, roots, eight
  branches, QR canopy, surface scatter. Full rules in `docs/02-island-scene.md`.
- **Runtime controls:** four canopy palettes, top-right; OBJ / GLB export in the
  viewer toolbar; orbit, pan and zoom.

### B. Soil and Seed (`Soil and Seed.html`)

- **Purpose:** the low-resolution companion — the same geology reduced to its
  essentials, presented as a build-up animation.
- **Extents:** 13 × 13 voxels in plan (2.08 m), y from −9 to +1 in soil voxels,
  plus the seed and sprout above.
- **Contents:** four horizons as independent slabs, three pebbles, a seed, a
  sprout. Full rules and the timeline in `docs/04-soil-animation.md`.
- **Runtime controls:** replay button, top-left; export; orbit.

## Interactions & behavior

| Trigger | Behavior |
| --- | --- |
| Page load (Scene B) | Assembly animation plays once, 5.6 s, driven by `requestAnimationFrame` |
| Replay button (Scene B) | Resets the clock to 0 and replays |
| Season button (Scene A) | Sets four leaf material colors + the petal color in place; no geometry rebuild, no remount |
| Drag | Orbit; damped, factor 0.08 |
| Wheel | Zoom |
| Toolbar export | Downloads the currently shown object as OBJ+MTL or GLB |

The season switch is deliberately a **material** change, not a geometry change:
the QR matrix, and therefore every voxel position, is identical across all four
palettes.

## State

Minimal, and all of it local to the scene:

- Scene A: `season` — one of `cherry | summer | ginkgo | pixel`, default
  `cherry`.
- Scene B: `t0` — the animation start timestamp. Animation state is derived from
  `(now - t0) / 1000`, so it is fully scrubbable; nothing accumulates.

No data fetching, no persistence, no network calls beyond the pinned three.js
CDN modules.

## Design tokens

See `docs/05-design-tokens.md` for the complete list: all 20 voxel material
colors, the four seasonal palettes, voxel dimensions, material roughness values,
lighting, camera framing, and the Classical tokens used by the 2D overlay.

## Assets

None external. Every surface is flat-shaded solid color — no textures, no image
maps, no icon files. The two inline SVG icons (replay arrow, none in Scene A) are
Lucide paths written inline. Fonts are Cormorant Garamond and Lora from Google
Fonts, used only by the prototype's 2D overlay.

three.js 0.184.0 is loaded from unpkg via an import map with subresource
integrity hashes. If the target codebase has three.js already, use its version
and drop the import map.

## Files

Design files, at the folder root so the pages run in place:

| File | What it is |
| --- | --- |
| `Voxel Island.html` | Scene A page: import map, overlay, camera framing, season buttons |
| `Soil and Seed.html` | Scene B page: overlay, animation loop, replay |
| `voxel-island.js` | Scene A generator — strata, tree, QR canopy, scatter, meshing |
| `soil-seed.js` | Scene B generator — horizons as separate slabs, seed, sprout, timeline |
| `qr.js` | Standalone QR encoder (byte mode, versions 1–4, RS ECC, mask scoring) |
| `three-d-stage.js` | Prototype viewer shell — renderer, lights, controls, exporters |
| `_ds/classical-.../styles.css` | Classical design system stylesheet, for the 2D overlay only |

Documentation:

| File | Covers |
| --- | --- |
| `docs/01-voxel-engine.md` | Coordinate space, the hash noise function, face-culled meshing, material grouping |
| `docs/02-island-scene.md` | Every generation rule in Scene A, layer by layer |
| `docs/03-qr-canopy.md` | The QR encoder, how the matrix becomes canopy, and how to change the payload |
| `docs/04-soil-animation.md` | Scene B geometry and the exact animation timeline |
| `docs/05-design-tokens.md` | All colors, dimensions, materials, lighting, camera, and overlay tokens |
| `docs/06-extending.md` | How to add scenes, seasons, strata, and the planned QR flatten animation |
