# 02 — Scene A: the island, layer by layer

`voxel-island.js`, exporting `buildIsland(THREE, { text, level, season })` →
`{ group, setSeason, qr, faces }`.

Constants: `V = 0.09` (voxel edge, metres), `N = 33` (grid), `OFF = 4` (the grass
margin around the QR footprint — 25 modules + 4 each side = 33).

Generation order matters: surface features are decided first, because the strata
loop reads them (`if (!has(x, y, z))`) to avoid overwriting the pond basin.

## Surface (y = 0)

Four mutually exclusive cases, tested in this order.

**1. Pond.** Centre `(x 9, z 24)`, radius `3.3`, with an elliptical distance so
it isn't a perfect circle:

```js
const pondDist = (x, z) => Math.hypot((x - 9) * 1.05, (z - 24) * 0.9);
```

Inside the radius: `water` at `y = -1` (so the water sits one voxel below the
grass line, giving a real basin), plus a second water voxel at `y = -2` where
`pondDist < PR - 1.6` — a deeper middle.

**2. Shore.** A one-voxel `shore` ring where `pondDist < PR + 1.1`, at `y = 0`.

**3. Dirt path.** A quadratic Bézier from the pond's edge to the island's east
corner, sampled at 60 points, with anything within `1.15` of a sample becoming
`path`:

```
P0 = [12.5, 26]   P1 = [21, 22.5]   P2 = [32, 17]
```

**4. Grass.** Three shades, chosen by `rnd(x, 7, z)`: 36 % `grass_light`, 42 %
`grass_mid`, 22 % `grass_deep`. The mix is what stops the lawn reading as a flat
plane under the studio lights.

## Soil horizons

| Horizon | y range | Composition |
| --- | --- | --- |
| Topsoil (A) | −1 … −3 | 70 % `topsoil_dark`, 30 % `topsoil_damp` |
| Subsoil sand (B upper) | −4 … −6 | 90 % `subsoil_sand`, 10 % `subsoil_clay` |
| Subsoil clay (B lower) | −7 … −9 | 90 % `subsoil_clay`, 10 % `subsoil_sand` |
| Bedrock (C) | −10 … −15 | 60 % `bedrock_grey`, 40 % `bedrock_deep` |

The 90/10 mixes are deliberately lopsided. Earlier drafts used 80/20 and the two
subsoil bands read as one speckled mass instead of two distinct strata — the
horizon boundary has to be legible from across the room.

### The bedrock taper

Bedrock is full-width for its first rows and then pulls in, so the island reads
as a torn-out plug of earth rather than a cube. `edge` is the distance to the
nearest plan boundary; `step` counts rows below the top of the bedrock:

```js
for (let y = -10; y >= -15; y--) {
  const step = -10 - y;                                        // 0 … 5
  const need = Math.max(0, (step - 2.6) * 1.5 + rnd(x, y, z) * 2.2 - 0.6);
  if (edge >= need) put(x, y, z, /* grey 60% : deep 40% */);
}
```

`step - 2.6` means rows 0–2 stay full width (`need` clamps to 0) and the taper
only bites from row 3 down. The `rnd * 2.2` term is what makes the silhouette
jagged rather than a smooth cone — it is re-evaluated per voxel, so the edge
breaks up per row.

### Hanging shards

Below the taper, a scatter of loose blocks so the underside isn't a clean cut:
where `edge > 8` and `rnd(x, 91, z) > 0.94`, add `bedrock_deep` at `y = -16`,
and 55 % of those also get `bedrock_grey` at `y = -17`.

## Trunk

Centred at `(16, 16)` — the QR centre, `OFF + 12`.

- `y = 1 … 9`: solid 3 × 3 of `bark`.
- `y = 10 … 16`: 3 × 3 with the four corners dropped **above** `y = 12`, so the
  trunk narrows to a plus-shaped section as it enters the canopy.
- `y = 1` root flare: single `root` voxels at ten offsets from centre —
  `(±2,0), (0,±2), (2,1), (−2,−1), (1,2), (−1,−2), (3,0), (0,−3)`. Asymmetric on
  purpose; a symmetrical flare looks machined.

## Roots

Six runs from the trunk base, each stepping outward 17 times and descending at
its own rate:

```js
const rootRuns = [
  { dir: [ 1, 0], rate: 0.34 }, { dir: [-1,  0], rate: 0.50 },
  { dir: [ 0, 1], rate: 0.40 }, { dir: [ 0, -1], rate: 0.28 },
  { dir: [ 1, 1], rate: 0.62 }, { dir: [-1, -1], rate: 0.55 },
];
```

At step `s` the run's depth is
`-min(8, round(1 + s * rate + rnd(x, i, z) * 0.9))`, and the run fills every
voxel from its previous depth down to the new one — so a root is a continuous
descending ribbon, not a dotted line. Grass cells are skipped, so roots never
punch through the lawn.

The two shallow-rate runs (0.28, 0.34) travel far enough laterally to reach the
cut faces before bottoming out at the 8-voxel clamp, which is the point: the
roots are **visible in the cross-section**, in `root` brown against the sand and
clay. Steps 1–7 of every run also place one lateral hair perpendicular to the
run direction, plus occasional extra hairs where `rnd(x, i + 50, z) > 0.72`.

## Branches

Eight arms — four orthogonal (length 5) and four diagonal (length 4). At step
`s`:

```js
y = 14 + Math.round(s * 0.5);   // rises as it goes out
put(x, y, z, 'bark');
if (s <= 2) put(x, y - 1, z, 'bark');   // thicker where it leaves the trunk
```

## Canopy

One column of leaves per **dark** QR module, positioned `x = OFF + c`,
`z = OFF + r` for module `(r, c)`. The canopy's *plan* is therefore exactly the
QR matrix; its *section* is a dome:

```js
const rn  = Math.min(1, Math.hypot(c - 12, r - 12) / 13.2);  // 0 centre → 1 rim
const jit = rnd(c, 3, r) > 0.62 ? 1 : 0;
const top = 25 - Math.round(8   * Math.pow(rn, 1.5)) + jit;
const bot = Math.min(top, 15 + Math.round(3.4 * Math.pow(rn, 1.9)));
```

- `top` falls from 25 at the centre to 17 at the rim; the `^1.5` exponent keeps
  the crown broad and flat before it drops away.
- `bot` rises from 15 at the centre to ~18 at the rim, so the canopy underside
  cups upward and the trunk is visible from a low angle.
- `jit` breaks the crown surface by one voxel on 38 % of columns. Without it the
  dome reads as a mathematical surface, which fights the hand-built look.

Each leaf voxel picks one of `leaf_1 … leaf_4` via `rnd(x, y, z)`, giving the
canopy tonal variation within a single season.

**Do not change `rn`'s divisor, the exponents, or `OFF` without re-checking the
overhead read.** The dome is what makes the QR legible from above while still
looking like a tree from the side; a steeper profile hides rim modules in
shadow.

## Surface scatter

Walked in grid order, only onto grass cells with nothing above them, capped so
the scatter stays sparse:

| Feature | Condition | Cap |
| --- | --- | --- |
| Rocks | `rnd(x, 42, z) > 0.988`, plus a second `stone` at `x+1` 45 % of the time | 14 |
| Flowers | `> 0.972` — single `flower` voxel | 18 |
| Fallen petals | `> 0.93` **and** within radius 11 of the trunk | 26 |

Petals are gated on the trunk radius so they read as having fallen from the tree.
Their color follows the season (see `docs/05-design-tokens.md`).

## Season switching

`setSeason(name)` reassigns four leaf material colors and the petal color in
place:

```js
s.leaves.forEach((c, i) => materials[`leaf_${i + 1}`].color.setHex(c));
materials.petal.color.setHex(s.petal);
```

No geometry is rebuilt, nothing remounts, and the QR matrix is untouched. An
export taken after a season switch carries that season's colors in its MTL.

## Camera framing

Fixed three-quarter near-isometric, computed from the object's bounding sphere so
it stays correct if the geometry changes:

```js
const dist = (r / Math.tan(cam.fov * Math.PI / 360)) * 1.18;
cam.position.copy(center).add(new THREE.Vector3(1, 0.82, 1).normalize().multiplyScalar(dist));
controls.target.copy(center);
```

The `(1, 0.82, 1)` direction is a touch lower than a true isometric `(1, 1, 1)` —
it shows more of the cut faces, which is where the geology is. `group.position.y`
is raised by `0.42` so the island floats clear of its contact shadow.
