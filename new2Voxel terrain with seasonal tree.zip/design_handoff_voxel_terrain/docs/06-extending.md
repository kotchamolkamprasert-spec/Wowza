# 06 — Extending the work

Notes for whoever picks this up, including the piece that was scoped but not
built.

## The QR flatten animation (planned, not built)

The original brief called for the isometric scene to smoothly flatten until the
canopy resolves into a readable 2D QR code. The geometry already supports it —
the canopy plan *is* the matrix — so this is a camera and transform problem, not
a modelling one.

The approach that fits what exists:

1. **Drive it from one clock**, the same way `soil-seed.js` does: a pure
   `animate(t)` with no accumulated state, so it can be scrubbed and exported to
   video.
2. **Interpolate the projection**, not the model. Animate the camera from the
   three-quarter `(1, 0.82, 1)` framing to top-down `(0, 1, 0)`, and cross-fade
   the perspective camera's FOV toward an orthographic projection (or lerp
   between two cameras' projection matrices). Perspective is what breaks the
   scan; orthographic top-down is what fixes it.
3. **Collapse `y` on the canopy** as the camera arrives: lerp each leaf column's
   height toward a single voxel at a common `y`. Because columns are already
   per-module, this is a scale on a per-column group — or, more cheaply, rebuild
   the canopy geometry once at `t = 1` and cross-fade.
4. **Fade everything that isn't the code.** Trunk, branches, soil and scatter
   should drop toward the background value as the flatten completes, leaving dark
   modules on beige. A scanner needs the quiet zone clean — the 4-voxel grass
   margin is already sized to be that quiet zone, so fade it to the background
   rather than removing it.
5. **Hold at the end.** Let the flattened code sit for two or three seconds so a
   phone has time to read it.

Order matters: rotate and orthographise *before* collapsing height, or the
canopy flattens into an unreadable smear mid-rotation.

## Adding a season

Add an entry to `SEASONS` in `voxel-island.js` — four leaf hexes plus a petal
hex — and the button appears automatically (the page iterates the object). Follow
the palette logic in `docs/05-design-tokens.md`: four steps of one hue for a
naturalistic season, four hues at matched value for a stylised one. Keep the
values within a narrow band or the QR stops scanning.

## Adding or changing a stratum

In Scene A, add a `for` loop over the new `y` range in the strata pass and a
color token. Two things to keep in mind:

- The bedrock taper reads `y` directly (`step = -10 - y`). Inserting a band above
  it shifts every depth below; update the taper's base.
- Keep adjacent bands far apart in value. The 90/10 mixes and the large sand-clay
  value step are what make four horizons legible; a subtle band just reads as
  noise in the neighbouring one.

In Scene B, add a new `Map` to `H`, then add it to `TIMELINE` with a cue 0.45 s
after the band below. The meshing and animation pick it up from there.

## Porting to another renderer

The generators are renderer-agnostic apart from the last 30 lines of each, where
`THREE.BufferGeometry` and `THREE.MeshStandardMaterial` appear. To port:

- Keep the cell-map + face-cull structure verbatim; it emits plain position,
  normal and UV arrays.
- Replace the buffer construction with the target's mesh API.
- Preserve the **per-part culling scope** in Scene B (see
  `docs/01-voxel-engine.md`) or the animation will show hollow slabs.
- Preserve the **named meshes and materials** if export matters.
- Keep `rnd()` exactly as written. It is the reason the scene is reproducible; a
  different hash gives a different island.

For a react-three-fiber target, `buildIsland` / `buildSoilAndSeed` fit cleanly in
a `useMemo` keyed on the payload text, with the season applied as a material prop
update rather than a rebuild.

## What was deliberately left out

- **No textures.** Flat color per material. Any texture at this voxel scale
  fights the faceted read.
- **No LOD, chunking, or instancing.** Unnecessary at 33³; see the performance
  note in `docs/01-voxel-engine.md` if you scale up.
- **No responsive layout.** The scenes fill the viewport and the camera reframes
  from the bounding sphere, but the 2D overlay is desktop-only.
- **No persistence.** Season and animation position reset on reload.
- **No multi-block QR.** Versions 5+ need codeword interleaving, which `qr.js`
  does not implement. If a payload ever needs it, use a library instead and feed
  its matrix into the same canopy loop.
