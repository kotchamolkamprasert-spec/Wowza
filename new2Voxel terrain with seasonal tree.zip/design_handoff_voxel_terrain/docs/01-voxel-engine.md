# 01 — The voxel engine

Both scenes are built the same way: fill a `Map` with occupied cells, then merge
each material's cells into one buffer geometry with interior faces removed. There
is no per-voxel `Mesh` and no `InstancedMesh` — the output is a handful of static
meshes, which is what makes the OBJ/GLB exports clean.

## Coordinate space

Integer grid coordinates `(x, y, z)`, converted to metres on merge.

- `x`, `z` — plan position, `0 … N-1`, centred on merge so the object sits on the
  world origin.
- `y` — height. **`y = 0` is the surface layer**, negative goes down through the
  soil, positive goes up into the tree. Every depth in this documentation is
  stated in grid units on that scale.

Conversion in Scene A:

```js
const cx = (x - (N - 1) / 2) * V;   // N = 33, V = 0.09
const cy = y * V;
const cz = (z - (N - 1) / 2) * V;
```

Scene B passes an explicit origin instead, because it merges several voxel sets
at two different scales into one coordinate space:

```js
mesh(cells, V,  [-C * V, 0, -C * V], buckets, horizon);  // soil, V = 0.16
mesh(seed,  SV, [0, V * 1.3, 0],     buckets, 'seed');   // seed, SV = 0.08
```

## Deterministic noise

All variation — which shade of soil a voxel takes, where the bedrock breaks off,
where flowers land — comes from one integer hash, never `Math.random()`. The
scene is therefore identical on every load, which matters: the exported mesh, the
screenshots and the live view all agree.

```js
function rnd(x, y, z) {
  let h = (x * 374761393 + y * 668265263 + z * 2246822519) ^ 0x9e3779b9;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
```

Returns `[0, 1)`. The third argument is often used as a *channel* rather than a
real coordinate — `rnd(x, 42, z)` for scatter, `rnd(x, 91, z)` for bedrock
shards, `rnd(x, 7, z)` for grass shade — so independent decisions at the same
cell don't correlate. Keep that convention when adding features: pick an unused
constant.

## Face-culled merging

Six faces, each a quad with an outward normal and unit UVs:

```js
const FACES = [
  { n: [ 1, 0, 0], v: [[.5,-.5,.5],[.5,-.5,-.5],[.5,.5,-.5],[.5,.5,.5]] },
  { n: [-1, 0, 0], v: [[-.5,-.5,-.5],[-.5,-.5,.5],[-.5,.5,.5],[-.5,.5,-.5]] },
  { n: [ 0, 1, 0], v: [[-.5,.5,.5],[.5,.5,.5],[.5,.5,-.5],[-.5,.5,-.5]] },
  { n: [ 0,-1, 0], v: [[-.5,-.5,-.5],[.5,-.5,-.5],[.5,-.5,.5],[-.5,-.5,.5]] },
  { n: [ 0, 0, 1], v: [[-.5,-.5,.5],[.5,-.5,.5],[.5,.5,.5],[-.5,.5,.5]] },
  { n: [ 0, 0,-1], v: [[.5,-.5,-.5],[-.5,-.5,-.5],[-.5,.5,-.5],[.5,.5,-.5]] },
];
```

For each occupied cell, emit a face only when the neighbour in that direction is
**absent from the same cell set**. Each quad becomes two triangles, wound
`0-1-2`, `0-2-3`.

### The culling scope is a design decision, not a detail

Scene A culls against the whole island: one cell set, so the block is a single
closed shell and no interior faces exist anywhere.

Scene B culls **per horizon**. Each stratum is meshed from its own `Map`, so it
gets its own top and bottom faces and is a closed solid on its own. That is what
lets a horizon slide independently during the assembly animation without
revealing that it is hollow. If you port Scene B and cull globally, the
animation will show open-topped shells mid-flight — this was an actual bug during
the build.

The trade is face count: per-horizon culling adds the interfaces between
horizons. At these grid sizes that is irrelevant, but a large scene that never
animates should cull globally.

## Material grouping

Cells store a material name (Scene A) or a `"horizon|material"` key (Scene B).
On merge, positions accumulate into one bucket per key; each bucket becomes one
`BufferGeometry` + one `MeshStandardMaterial`, and **both the mesh and the
material are named**:

```js
const mesh = new THREE.Mesh(geometry, material);
mesh.name = 'subsoil_clay';     // becomes an OBJ group / GLB node name
material.name = 'subsoil_clay'; // becomes an MTL entry
```

That naming is why the exports are usable: opening the OBJ in Blender or
MagicaVoxel gives you named objects per stratum, not one anonymous soup.

In Scene B the meshes are additionally parented into a `THREE.Group` per horizon
(`topsoil`, `sand`, `clay`, `bedrock`, `pebbles`, `seed`, `sprout`) — the
animation moves those groups, never the meshes.

## Materials

All materials are `MeshStandardMaterial` with `flatShading: true` — the faceted
look depends on it. Roughness varies by substance; nothing is metallic except a
hint on water:

| Substance | roughness | metalness |
| --- | --- | --- |
| Water | 0.25 | 0.15 |
| Seed shell | 0.55 | 0 |
| Bedrock | 0.70 | 0 |
| Sprout | 0.75 | 0 |
| Leaves | 0.85 | 0 |
| Everything else (soil, grass, bark, stone) | 0.92 | 0 |

## Performance notes

Scene A is roughly 33 × 33 × 44 cells of potential volume with about 20
materials, and merges in a few milliseconds. No LOD, no chunking, no worker. If
you scale the grid up substantially, the two things to change first are: emit
into pre-sized `Float32Array`s instead of pushing to JS arrays, and greedy-mesh
coplanar runs of the same material rather than emitting one quad per face.
