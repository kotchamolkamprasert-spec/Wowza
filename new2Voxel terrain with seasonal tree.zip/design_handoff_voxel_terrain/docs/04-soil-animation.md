# 04 — Scene B: soil, seed, and the assembly animation

`soil-seed.js`, exporting `buildSoilAndSeed(THREE)` →
`{ group, parts, animate, duration }`.

Constants: `V = 0.16` (soil voxel edge — 1.8× Scene A, deliberately chunky),
`N = 13` (grid), `SV = 0.08` (the seed and sprout are modelled at half scale so
they can hold an organic shape without a fine grid everywhere).

## Geometry

Same four horizons as Scene A, compressed:

| Horizon group | y range | Composition |
| --- | --- | --- |
| `topsoil` | 0, −1 | 62 / 70 % `topsoil_dark`, remainder `topsoil_damp` |
| `sand` | −2 … −3 | 88 % `subsoil_sand`, 12 % `subsoil_clay` |
| `clay` | −4 … −5 | 88 % `subsoil_clay`, 12 % `subsoil_sand` |
| `bedrock` | −6 … −8 (tapered) | 60 % `bedrock_grey`, 40 % `bedrock_deep` |

**The planting dip** is a 3 × 3 hole in the `y = 0` surface layer at the grid
centre `(6, 6)`; `y = -1` stays solid, so the dip is one voxel deep and the seed
sits *in* the earth rather than on it.

Bedrock taper, same shape as Scene A with tighter numbers:

```js
const need = Math.max(0, (-6 - y - 1.2) * 1.5 + rnd(x, y, z) * 1.8 - 0.5);
if (edge >= need) put(...);
```

Plus a shard row at `y = -9` where `edge > 3` and `rnd(x, 91, z) > 0.86`.

**Pebbles** — three single `stone` voxels at `y = 1`, hand-placed at
`(2, 9)`, `(10, 3)`, `(4, 2)`. Hand-placed rather than scattered because at three
items a random distribution reliably clumps.

## The seed

A half-scale ellipsoid with half-extents `[2.4, 3.6, 2.0]` seed-voxels, so about
`0.38 × 0.58 × 0.32` m. Two shaping rules on top of the ellipsoid test:

```js
if (y > 2 && Math.abs(x) + Math.abs(z) > 0) continue;   // single-voxel tip
if (y > 1 && Math.abs(x) + Math.abs(z) > 1) continue;   // pinch below it
```

That gives an almond/teardrop profile rather than an egg. The **hilum scar** —
`seed_scar`, the darker patch where a seed attached to its pod — sits on the
`−z` face: `z <= -1 && |x| <= 1 && y in [-2, 1]`. The top two rows take
`seed_tip` (lighter) and the rest `seed_shell`.

Placed at origin `[0, V * 1.3, 0]` = 0.208 m, which seats it in the dip with the
tip clear of the surface.

## The sprout

Deliberately minimal — 5 stem voxels and 6 leaf voxels, stepped:

```js
for (let y = 0; y <= 4; y++) sprout.set(`0,${y},0`, 'sprout_stem');
leaves at (-1,3) (-2,4) (1,2) (2,3) (-1,4) (1,3)
```

Meshed at **origin** rather than in place, then its group is positioned at
`seedOrigin.y + 3.5 * SV = 0.488 m`. That is what lets the growth animation
scale `y` from 0 without the sprout sinking into the soil — it grows from its
own base.

## The animation

One-shot, 5.6 s, fully derived from elapsed time. No tweens, no state machine.

```js
const ease = (t) => 1 - Math.pow(1 - t, 3);                       // cubic out
const seg  = (t, a, b) => clamp01((t - a) / (b - a));             // window
const FALL = 1.9;                                                 // drop height, m
```

### Timeline

| t (s) | Event |
| --- | --- |
| 0.00 | `bedrock` starts falling |
| 0.45 | `clay` starts |
| 0.90 | `sand` starts |
| 1.35 | `topsoil` starts |
| 2.10 | `pebbles` start |
| 2.50 | `seed` starts |
| 3.50 | sprout begins growing |
| 5.40 | sprout at full size |
| 5.60 | end (rest state) |

Every drop lasts **0.95 s** and overlaps its neighbour — the 0.45 s stagger
against a 0.95 s duration means three horizons are in the air at once, which
reads as a stack assembling itself rather than a queue.

```js
for (const [name, start] of Object.entries(TIMELINE)) {
  const p = ease(seg(t, start, start + 0.95));
  parts[name].position.y = (1 - p) * FALL;
  parts[name].visible = t >= start - 0.001;
}
```

Each part is hidden until its cue, then eased from `+1.9 m` down to `0`. Cubic-out
means it arrives decelerating — it settles rather than lands. Nothing bounces;
soil shouldn't.

### Sprout growth

```js
const g = ease(seg(t, 3.5, 5.4));
parts.sprout.visible = g > 0;
parts.sprout.scale.set(0.35 + 0.65 * g, Math.max(0.001, g), 0.35 + 0.65 * g);
```

`y` scales from ~0 to 1 while `x`/`z` only go from 0.35 to 1 — the sprout
thickens far less than it lengthens, so it reads as extending rather than
inflating. `Math.max(0.001, g)` avoids a zero-scale matrix.

### Driving it

```js
let t0 = performance.now();
const tick = () => {
  animate(Math.min(duration, (performance.now() - t0) / 1000));
  requestAnimationFrame(tick);
};
tick();
replayButton.addEventListener('click', () => { t0 = performance.now(); });
```

`animate(t)` is a pure function of `t` — call it with any value to scrub, and
`t >= duration` is the rest state. Porting to a timeline library, a scroll
position, or a video export is a matter of feeding it a different clock.

### Why the horizons are separate groups

Because each horizon is meshed from its own cell map with culling scoped to that
map (see `docs/01-voxel-engine.md`), every slab is a closed solid with its own
top and bottom faces. Moving one mid-animation shows solid earth, not a hollow
shell. Any port must preserve that: one mesh set per animated part, culled within
the part.

## Exporting

An export taken after the animation settles is the fully assembled block. Because
the parts keep their own transforms, an export taken mid-animation captures the
exploded state — occasionally useful for a diagram, but not the intended
deliverable.
