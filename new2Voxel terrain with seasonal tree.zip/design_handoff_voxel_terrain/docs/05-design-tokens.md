# 05 — Design tokens

Every value in both scenes. These are final; build to them exactly.

## Voxel palette

### Surface

| Token | Hex | Used for |
| --- | --- | --- |
| `grass_light` | `#93bb61` | 36 % of grass cells |
| `grass_mid` | `#80a852` | 42 % of grass cells |
| `grass_deep` | `#6b8c44` | 22 % of grass cells |
| `stone` | `#8b9497` | Surface rocks, pebbles |
| `flower` | `#f6f2e4` | Single-voxel flowers |
| `water` | `#5c93a6` | Pond |
| `shore` | `#c0a377` | Pond rim |
| `path` | `#a88f6a` | Dirt path |

### Soil horizons

| Token | Hex | Horizon |
| --- | --- | --- |
| `topsoil_dark` | `#402d20` | A — dominant |
| `topsoil_damp` | `#533b26` | A — variation |
| `subsoil_sand` | `#cba473` | B upper — dominant |
| `subsoil_clay` | `#9c5b31` | B lower — dominant |
| `bedrock_grey` | `#7d878c` | C — dominant |
| `bedrock_deep` | `#69747b` | C — variation, shards |

The sand-to-clay jump (`#cba473` → `#9c5b31`) is the largest value step in the
cross-section, and it is doing the work of separating the two B bands. Don't
close it.

### Wood and growth

| Token | Hex | Used for |
| --- | --- | --- |
| `bark` | `#4b3627` | Trunk, branches |
| `root` | `#5a3a1e` | Roots, surface flare |
| `seed_shell` | `#8a5a33` | Seed body |
| `seed_tip` | `#c0946a` | Seed top two rows |
| `seed_scar` | `#5d3a1f` | Hilum patch, −z face |
| `sprout_stem` | `#4e7a35` | Sprout stem |
| `sprout_leaf` | `#82b757` | Sprout leaves |

`root` is lighter than `bark` on purpose — it has to separate from `topsoil_dark`
where the roots cross the cut faces.

## Seasonal canopy palettes

Four leaf shades plus a fallen-petal color, applied to materials `leaf_1 … leaf_4`
and `petal`. Assigned per voxel by hash, so all four appear throughout the crown.

| Season | leaf_1 | leaf_2 | leaf_3 | leaf_4 | petal |
| --- | --- | --- | --- | --- | --- |
| **Cherry Blossom** | `#f3c2d2` | `#e6a6bd` | `#f9d9e3` | `#da8fa9` | `#f5d2de` |
| **Summer Green** | `#6aa84f` | `#578e41` | `#7cba5d` | `#466f34` | `#8cbf6a` |
| **Golden Ginkgo** | `#e9c644` | `#d6ad32` | `#f3da6c` | `#c0942a` | `#e3bd54` |
| **Pixel Mix** | `#3f9c8f` | `#6aab4e` | `#e0873c` | `#ecc94b` | `#d98f43` |

Cherry, Summer and Ginkgo are each four steps of one hue — light, base, lighter,
dark — so the crown has internal shading. Pixel Mix breaks that rule on purpose:
four different hues at similar value, which is what makes it read as pixel-art
rather than as foliage. All four hold their luminance band tightly enough that
the QR still scans (see `docs/03-qr-canopy.md`).

Defaults to Cherry Blossom.

## Dimensions

| | Scene A (island) | Scene B (soil) |
| --- | --- | --- |
| Voxel edge | 0.09 m | 0.16 m |
| Sub-voxel edge | — | 0.08 m (seed, sprout) |
| Plan grid | 33 × 33 (2.97 m) | 13 × 13 (2.08 m) |
| y range | −17 … ~26 (≈3.9 m) | −9 … ~7 |
| Grass margin around QR | 4 voxels | — |
| Float above shadow plane | +0.42 | +0.34 |

## Material response

`MeshStandardMaterial`, `flatShading: true` everywhere.

| Substance | roughness | metalness |
| --- | --- | --- |
| Water | 0.25 | 0.15 |
| Seed shell | 0.55 | 0 |
| Bedrock | 0.70 | 0 |
| Sprout | 0.75 | 0 |
| Leaves | 0.85 | 0 |
| Soil, grass, bark, stone | 0.92 | 0 |

## Scene

| | Value |
| --- | --- |
| Background | `#f2e8d7` (warm beige, both scenes) |
| Lighting | Studio: ambient + key directional with soft shadow + fill directional at 0.8 |
| Camera | Perspective, framed from the bounding sphere |
| Camera direction | `(1, 0.82, 1)` normalised — three-quarter, just below isometric |
| Camera distance | `radius / tan(fov/2) × 1.18` |
| Controls | Orbit, damped, `dampingFactor: 0.08` |
| Ground | Soft contact shadow only; no visible floor plane |

The background is warmer than the Classical ground (`#f3f2f2`) — a neutral grey
made the soil browns look muddy under the studio key. The beige is picked to sit
between the sand and the ground.

## 2D overlay — Classical design system

Prototype chrome only. Tokens from
`_ds/classical-1283e268-107d-429e-aaf4-33746026f2d4/styles.css`.

| Element | Treatment |
| --- | --- |
| Kicker | `--font-body`, 0.72 rem, `letter-spacing: .14em`, uppercase, `--color-accent-700`, `font-feature-settings: "tnum"` |
| Title | `--font-heading` (Cormorant Garamond), 400, 2.6 rem, `line-height: 1.02`, `--color-text` |
| Body | `--font-body` (Lora), 0.86 rem, `line-height: 1.6`, `--color-neutral-800`, max 17 rem, `text-wrap: pretty` |
| Payload line | Italic, 0.8 rem, `--color-accent-700`, above it a 1 px `--color-divider` rule |
| Season buttons | `.btn.btn-secondary`, left-aligned, 12.5 rem column, `gap: --space-2`; selected state `aria-pressed="true"` → `--color-accent` border, `--color-accent-700` text, `— ` prefix |
| Replay button | `.btn.btn-icon` with an inline Lucide rotate-ccw path, 18 px, `stroke-width: 1.6` |
| Overlay inset | `--space-6` (27.6 px) from the viewport edge |

Relevant token values: `--color-bg #f3f2f2`, `--color-text #201f1d`,
`--color-accent #b68235`; spacing scale 4.6 / 9.2 / 13.8 / 18.4 / 27.6 / 36.8 px;
radii 2 / 4 / 7 px.

Note that the selected-state marker is a border and a prefix, not a fill —
Classical applies color as stroke, never as a filled block.

## Dependencies

three.js **0.184.0**, loaded from unpkg via an import map with SRI hashes:
`three.module.js`, `OrbitControls`, `OBJExporter`, `GLTFExporter`. No other
runtime dependency; no build step; no npm install.
