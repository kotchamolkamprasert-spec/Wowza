# 03 — The QR canopy

The canopy's plan is a real QR code, not a QR-like pattern. `qr.js` is a
dependency-free encoder written for this piece; `voxel-island.js` plots its dark
modules as leaf columns.

## The payload

```
text:    the god father is Dr.krirk
mode:    byte (0100)
version: 2  →  25 × 25 modules
level:   M  (≈15% recovery)
mask:    chosen by penalty scoring
```

26 bytes of payload. Version 2-M carries 28 data codewords, of which 2 go to the
mode and length header, leaving 26 — the payload fits exactly, with no padding
codewords. That is a coincidence of this particular string, and it is why the
version cannot be lowered.

`buildIsland` asserts the size:

```js
if (qr.size !== 25) throw new Error(`qr: expected a 25-module code, got ${qr.size}`);
```

The 33-wide grid is sized as `25 + 4 + 4`. A longer payload pushes the code to
version 3 (29 modules) or 4 (33), which needs the grid and `OFF` resized to
match — see "Changing the payload" below.

## What the encoder implements

`qr.js` is ~200 lines and covers exactly what a single-block code needs:

- **GF(2⁸) arithmetic** — log/antilog tables over the QR primitive polynomial
  `0x11d`.
- **Reed–Solomon ECC** — generator polynomial by degree, synthetic division.
  Verified against the published version 1-M `HELLO WORLD` vector: expected
  `196,35,39,119,235,215,231,226,93,23`, produced byte-identical.
- **Function patterns** — three finder patterns with separators, both timing
  rows, the version-2 alignment pattern at `(size−7, size−7)`, the dark module.
- **Data placement** — the standard two-column boustrophedon, skipping the timing
  column and every reserved cell.
- **Masking** — all eight mask patterns applied, each scored on the four standard
  penalty rules (runs of five+, 2 × 2 blocks, finder-like 1:1:3:1:1 sequences,
  dark-ratio deviation); the lowest score wins.
- **Format information** — 5 data bits, BCH(15,5) with generator `0x537`, XORed
  with `0x5412`, written to both format areas.

Supported: versions 1–4, levels L/M/Q/H where a single-block configuration
exists. Not supported, because nothing here needs it: multi-block interleaving
(version 5+), numeric/alphanumeric/Kanji modes, version information blocks
(version 7+), ECI.

Verification performed during the build: the generated matrix was decoded back
by an independent routine — format info BCH remainder 0, all 16 RS syndromes
zero, mode 4, length 26, decoded string identical to the input.

## From matrix to canopy

```js
for (let r = 0; r < 25; r++)
  for (let c = 0; c < 25; c++) {
    if (!qr.modules[r][c]) continue;      // light modules stay empty sky
    const x = OFF + c, z = OFF + r;       // module (r,c) → grid (x,z)
    for (let y = bot; y <= top; y++) put(x, y, z, `leaf_${1 + rnd(...) * 4 | 0}`);
  }
```

Two properties this relies on:

- **Row → z, column → x.** Viewed from `+y` looking down with `+z` toward the
  viewer, this puts module `(0,0)` at the far-left corner. If your renderer's
  down-view flips an axis, the code mirrors and stops scanning — mirror the loop,
  not the matrix.
- **Light modules must be genuinely empty.** No leaf voxels, no scatter, nothing
  overhanging into a light cell from a neighbouring column. The dome profile is
  per-column precisely so a tall centre column can never spill sideways into a
  light module.

The four leaf shades are all "dark" as far as scanning goes — a scanner
thresholds luminance, and every palette keeps its four leaf colors within a
narrow band against the beige ground. This is why Pixel Mix works despite mixing
teal, green, orange and yellow: the hues differ, the values don't.

## Scanning it

Point a phone at the scene from directly overhead, orthographically if possible.
In perspective the rim modules foreshorten and most scanners still cope, but a
top-down orthographic camera is the reliable read. This is also the setup the
planned flatten animation resolves to — see `docs/06-extending.md`.

## Changing the payload

1. Set the new string in the `buildIsland` call in `Voxel Island.html`.
2. Read back the version the encoder chose (it is logged, and returned as
   `qr.version` / `qr.size`).
3. If `size` is no longer 25: set `N = size + 8` and keep `OFF = 4`; update the
   canopy centre `CX/CZ = OFF + (size − 1) / 2`, the `rn` divisor
   (`≈ size * 0.53`), and the `c − 12` / `r − 12` centre offsets in the canopy
   loop. The trunk sits at the canopy centre and follows automatically.
4. Re-check the overhead read before shipping. A larger version has smaller
   modules relative to the dome, and the profile may need flattening.

Keep the level at M. Lower (L) shrinks the matrix but leaves less recovery margin
for a code read off a shaded 3D surface; higher (Q/H) pushes to a larger version
for no visible benefit.
